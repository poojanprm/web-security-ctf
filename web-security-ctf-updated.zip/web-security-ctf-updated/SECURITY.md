# Security Policy

This repository contains an intentionally vulnerable, standalone client-side Web Security CTF.

The insecure client-side logic is part of the challenge design and should not be treated as production security guidance.

If you find an issue outside the intended challenge behavior, please open an issue with a clear description, reproduction steps, expected behavior, actual behavior, and impact.

Only use the techniques demonstrated by this project against systems you own or have explicit permission to test.
