# Web Security CTF — Write-up

> ⚠️ **SPOILER WARNING:** This document contains the complete solution and final flag.

## 1. Reconnaissance

Open `challenge/challenge.html` and inspect the application using browser Developer Tools.

Useful areas include the page source, JavaScript, Console, URL parameters, and browser storage.

## 2. Inspect the JavaScript

The application contains route information, including a Base64-encoded value:

```text
YXJjaGl2ZQ==
```

Decoding it gives:

```text
archive
```

This identifies `archive` as an important route.

## 3. Identify Decoy Flags

The JavaScript contains fake/decoy flags. These are intentionally not the final answer.

## 4. Investigate Client-Side Authentication

The login logic performs a client-side check and, when successful, stores:

```text
employee = verified
```

in LocalStorage.

This is intentionally insecure challenge behavior and demonstrates why browser-controlled storage should not be trusted as a real authorization boundary.

## 5. Find the Final Conditions

The archive page requires the relevant URL and browser state, including:

```text
page = archive
employee = verified
token = alpha-42
```

Once the required conditions are satisfied, the application displays the final flag.

## 🏁 Final Flag

```text
FLAG{browser_exploration_master}
```

## 🔐 Security Lessons

- Client-side JavaScript can be inspected by the user.
- LocalStorage is controlled by the browser user.
- URL parameters are user-controlled input.
- Base64 is encoding, not encryption.
- Sensitive authorization decisions should be enforced server-side.
