# 🚩 Web Security CTF

A **beginner/intermediate Web Security Capture The Flag (CTF)** challenge built as a standalone browser-based cybersecurity learning project.

The challenge focuses on **web reconnaissance, JavaScript analysis, client-side security logic, LocalStorage, URL parameters, Base64 encoding/decoding, hidden routes, and decoy flags**.

## 🎯 Objective

Investigate the web application, follow the available clues, and discover the hidden flag.

## 🧠 Concepts Covered

- Web Reconnaissance
- HTML Source Inspection
- JavaScript Analysis
- Client-Side Authentication Logic
- LocalStorage
- URL Parameter Manipulation
- Base64 Encoding/Decoding
- Hidden Routes
- Decoy/Fake Flags
- Browser Developer Tools
- Client-Side Security

## 🏆 Difficulty

**Beginner / Intermediate**

## 🛠️ Technologies

- HTML5
- CSS3
- JavaScript
- Browser Developer Tools

## 🏗️ Architecture

This is a **standalone client-side web application**.

- ❌ No backend server
- ❌ No database
- ❌ No API
- ❌ No external dependencies
- ✅ HTML
- ✅ CSS
- ✅ JavaScript
- ✅ Browser-based functionality

All challenge logic runs locally in the browser.

## 🚀 How to Run

No installation or server setup is required.

Open:

```text
challenge/challenge.html
```

in a modern web browser.

Use browser Developer Tools while solving the challenge.

## 🔎 Challenge

Investigate the application and find the final flag. You may need to explore:

- Page source
- JavaScript
- Browser Console
- URL parameters
- LocalStorage
- Encoded values
- Hidden application routes

### ⚠️ Spoiler Warning

Try solving the challenge yourself before opening the write-up.

## 📖 Write-up

Complete solution:

[`writeup/WRITEUP.md`](writeup/WRITEUP.md)

> ⚠️ **SPOILER:** The write-up contains the complete solution and final flag.

## 📁 Project Structure

```text
web-security-ctf/
│
├── README.md
├── .gitignore
├── LICENSE
├── SECURITY.md
│
├── challenge/
│   └── challenge.html
│
└── writeup/
    └── WRITEUP.md
```

## 🎓 Learning Objectives

This project was created to gain practical experience with:

- Web application reconnaissance
- Inspecting client-side JavaScript
- Understanding browser-controlled storage
- Investigating URL parameters
- Identifying client-side security weaknesses
- Understanding Base64 encoding
- Following multiple clues during a security investigation

## 🔐 Security Lessons

This CTF demonstrates why sensitive authentication and authorization decisions should **not rely solely on client-side logic**.

Client-side JavaScript, LocalStorage, and URL parameters are accessible or controllable by the browser user. In real-world applications, sensitive security decisions should be enforced on the **server side**.

## ⚠️ Disclaimer

This project is intentionally designed with insecure client-side behavior for cybersecurity education and CTF practice.

It is intended only for cybersecurity learning, CTF practice, local experimentation, and authorized security testing.

Do not use the techniques demonstrated in this project against systems that you do not own or do not have explicit permission to test.

## 👨‍💻 Author

**Poojan Parmar**

Cybersecurity learning project focused on **Web Application Security and Security Testing**.

## 📌 Project Status

**Version 1.0 — Completed**

Future versions may introduce additional stages and more advanced Web Security concepts.
